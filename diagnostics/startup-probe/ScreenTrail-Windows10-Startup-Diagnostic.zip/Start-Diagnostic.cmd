@echo off
setlocal
title ScreenTrail startup diagnostic
set "ScreenTrailProbePowerShell=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "ScreenTrailProbePowerShell=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%ScreenTrailProbePowerShell%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Collect-ScreenTrailStartup.ps1"
echo.
echo ScreenTrail diagnostic finished. The result is saved on your Desktop.
pause
endlocal
