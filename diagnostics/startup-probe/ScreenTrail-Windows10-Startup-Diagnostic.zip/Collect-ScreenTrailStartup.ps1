﻿[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
$started=Get-Date
$desktop=[Environment]::GetFolderPath('DesktopDirectory')
$name='ScreenTrail-시작진단-'+$started.ToString('yyyyMMdd-HHmmss')
$folder=Join-Path $desktop $name
$zip=$folder+'.zip'
$null=New-Item -ItemType Directory -Path $folder
$utf8=New-Object Text.UTF8Encoding($true)
$result=[ordered]@{ startedUtc=$started.ToUniversalTime().ToString('o'); diagnosticCompleted=$false; applicationStarted=$false; samples=@(); notes=@() }
$process=$null
function Save-Json([string]$File,$Value) { [IO.File]::WriteAllText((Join-Path $folder $File),(ConvertTo-Json -InputObject $Value -Depth 10),$utf8) }
try {
    $existing=@(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'ScreenTrail*' } | ForEach-Object { @{ name=$_.ProcessName; processId=$_.Id; sessionId=$_.SessionId } })
    $result.existingProcesses=$existing
    $os=Get-CimInstance Win32_OperatingSystem
    $result.os=@{ caption=$os.Caption; version=$os.Version; build=$os.BuildNumber; architecture=$os.OSArchitecture; productType=$os.ProductType }
    $result.is64BitProcess=[Environment]::Is64BitProcess
    $result.cpu=@(Get-CimInstance Win32_Processor | Select-Object Name,Manufacturer,Architecture)
    $registered=Get-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ScreenTrail' -ErrorAction SilentlyContinue
    $locations=@()
    if($null -ne $registered -and $registered.InstallLocation) { $locations += [string]$registered.InstallLocation }
    $locations += Join-Path $env:LOCALAPPDATA 'Programs\ScreenTrail'
    $executable=@($locations | Select-Object -Unique | ForEach-Object { Join-Path $_ 'ScreenTrail.exe' } | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1)
    if($executable.Count -eq 0) { throw '설치된 ScreenTrail.exe를 찾지 못했습니다. 설치 등록과 기본 설치 폴더만 확인했습니다.' }
    $executable=$executable[0]
    $file=Get-Item -LiteralPath $executable
    $result.application=@{ path=$file.FullName; bytes=$file.Length; version=$file.VersionInfo.FileVersion; sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant() }
    if($existing.Count -gt 0) {
        $result.launchSkipped='이미 ScreenTrail 관련 프로세스가 실행 중이어서 추가 실행하지 않았습니다. 기존 프로세스는 종료하지 않았습니다.'
        $result.diagnosticCompleted=$true
    } else {
        Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
public static class ScreenTrailProbeWindows {
    public delegate bool EnumProc(IntPtr h,IntPtr p);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc f,IntPtr p);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h,StringBuilder s,int n);
    public class Window { public long Handle; public string Title; public string ClassName; public bool Visible; }
    public static Window[] Read(int pid) {
        var list=new List<Window>();
        EnumWindows((h,p)=> { uint owner; GetWindowThreadProcessId(h,out owner); if(owner!=pid) return true;
            var title=new StringBuilder(512); var cls=new StringBuilder(256); GetWindowText(h,title,title.Capacity); GetClassName(h,cls,cls.Capacity);
            list.Add(new Window { Handle=h.ToInt64(),Title=title.ToString(),ClassName=cls.ToString(),Visible=IsWindowVisible(h) }); return true;
        },IntPtr.Zero); return list.ToArray();
    }
}
'@
        # Environment changes exist only in this diagnostic process and its child.
        $variables=@{ DOTNET_HOST_TRACE='1'; DOTNET_HOST_TRACEFILE=(Join-Path $folder 'dotnet-host-trace.log'); DOTNET_HOST_TRACE_VERBOSITY='4'; COREHOST_TRACE='1'; COREHOST_TRACEFILE=(Join-Path $folder 'corehost-trace.log'); COREHOST_TRACE_VERBOSITY='4' }
        $previous=@{}
        foreach($key in $variables.Keys) { $previous[$key]=[Environment]::GetEnvironmentVariable($key,'Process') }
        try {
            foreach($key in $variables.Keys) { [Environment]::SetEnvironmentVariable($key,$variables[$key],'Process') }
            $launchStarted=Get-Date
            $process=Start-Process -FilePath $executable -WorkingDirectory (Split-Path $executable) -PassThru -RedirectStandardOutput (Join-Path $folder 'startup-stdout.txt') -RedirectStandardError (Join-Path $folder 'startup-stderr.txt')
        } finally { foreach($key in $variables.Keys) { [Environment]::SetEnvironmentVariable($key,$previous[$key],'Process') } }
        $result.applicationStarted=$true; $result.processId=$process.Id
        foreach($seconds in @(3,10)) {
            $remaining=[int][Math]::Ceiling(($seconds-((Get-Date)-$launchStarted).TotalSeconds)*1000)
            if($remaining -gt 0) { Start-Sleep -Milliseconds $remaining }
            $process.Refresh()
            $sample=[ordered]@{ elapsedSeconds=[Math]::Round(((Get-Date)-$launchStarted).TotalSeconds,2); exited=$process.HasExited; windows=@() }
            if($process.HasExited) { $sample.exitCode=$process.ExitCode; $sample.exitCodeHex=('0x{0:X8}' -f ($process.ExitCode -band 0xffffffffL)) }
            else { $sample.responding=$process.Responding; $sample.windows=@([ScreenTrailProbeWindows]::Read($process.Id)) }
            $result.samples += $sample
        }
        $result.diagnosticCompleted=$true
    }
} catch { $result.failure=$_.Exception.Message; $result.failureType=$_.Exception.GetType().FullName }
finally {
    try {
        $events=@(Get-WinEvent -FilterHashtable @{ LogName='Application'; StartTime=$started.AddMinutes(-10) } -ErrorAction SilentlyContinue | Where-Object { $_.ProviderName -in @('.NET Runtime','Application Error','Windows Error Reporting','SideBySide') -and $_.Message -match 'ScreenTrail' } | Select-Object -First 20 TimeCreated,Id,ProviderName,Message)
        Save-Json 'application-events.json' $events
        $result.runtimeError80131506Observed=@($events | Where-Object { $_.Message -match '(?i)80131506' }).Count -gt 0
        $result.explicitCetMessageObserved=@($events | Where-Object { $_.Message -match '(?i)\bCET\b|shadow.stack' }).Count -gt 0
    } catch { $result.notes += ('이벤트 기록을 읽지 못했습니다: '+$_.Exception.Message) }
    try {
        $log=Join-Path $env:LOCALAPPDATA 'ScreenTrail\Logs\app.log'
        if(Test-Path -LiteralPath $log -PathType Leaf) {
            # Keep only structured error identifiers and stack frames, not arbitrary messages.
            $lines=@(Get-Content -LiteralPath $log -Tail 120 -ErrorAction Stop | Where-Object { $_ -match '^\d{4}-\d{2}-\d{2}T\S+\s+[A-Za-z0-9_.+`]+\s+HResult=[A-Fa-f0-9]{8}\s*$' -or $_ -match '^\s+at\s+[A-Za-z0-9_.+`<>]+\(' })
            [IO.File]::WriteAllLines((Join-Path $folder 'app-error-identifiers.txt'),[string[]]$lines,$utf8)
        }
    } catch { $result.notes += '앱 오류 기록을 읽지 못했습니다.' }
    if($null -ne $process) { $process.Dispose() } # Does not stop the application.
    $result.finishedUtc=[DateTime]::UtcNow.ToString('o')
    Save-Json 'result.json' $result
    $readme=@'
ScreenTrail 시작 진단 결과

이 파일은 설치된 원래 ScreenTrail을 한 번 실행하여 시작 상태를 기록한 것입니다.
기존 ScreenTrail 프로세스가 있으면 추가 실행하지 않으며, 앱을 강제로 종료하지 않습니다.
앱 파일, 설치 상태, 보안 완화 설정, 라이선스와 사용자 설정을 변경하지 않습니다.

포함: Windows 버전, CPU 종류, 앱 버전과 파일 해시, 실행 종료 코드,
창 제목, .NET 시작 추적, 최근 ScreenTrail 관련 Windows 오류 기록.
앱 오류 기록에서는 오류 종류와 호출 경로만 추립니다.
PC 사용자 이름과 설치 경로가 기록에 포함될 수 있습니다.
화면 캡처, 캡처 이미지, OCR 본문, 라이선스 파일, 설정 파일은 수집하지 않습니다.

이 압축 파일을 자동으로 전송하지 않습니다. 내용을 확인한 뒤 진단을 요청한 대화에 첨부하세요.
'@
    [IO.File]::WriteAllText((Join-Path $folder 'README.txt'),$readme,$utf8)
    $staging=Join-Path ([IO.Path]::GetTempPath()) ('ScreenTrail-probe-zip-'+[Guid]::NewGuid().ToString('N'))
    try {
        $null=New-Item -ItemType Directory -Path $staging
        # A healthy app still owns trace/output handles. Snapshot with shared-read
        # access, then zip closed files without stopping or altering the app.
        foreach($source in Get-ChildItem -LiteralPath $folder -File) {
            $sourceStream=$null; $snapshot=$null
            try {
                $sourceStream=[IO.File]::Open($source.FullName,[IO.FileMode]::Open,[IO.FileAccess]::Read,([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
                $snapshot=[IO.File]::Create((Join-Path $staging $source.Name))
                $sourceStream.CopyTo($snapshot)
            } finally { if($null -ne $snapshot) { $snapshot.Dispose() }; if($null -ne $sourceStream) { $sourceStream.Dispose() } }
        }
        Compress-Archive -Path (Join-Path $staging '*') -DestinationPath $zip -CompressionLevel Optimal -ErrorAction Stop
    } catch { $result.diagnosticCompleted=$false; $result.archiveFailure=$_.Exception.Message; $result.notes += ('압축하지 못했습니다. 진단 폴더를 확인하세요: '+$_.Exception.Message); Save-Json 'result.json' $result }
    finally { if(Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force } }
    Write-Host ''
    if(Test-Path -LiteralPath $zip) { Write-Host ('진단 파일: '+$zip) }
    else { Write-Host ('진단 폴더: '+$folder) }
    if($result.Contains('failure')) { Write-Host ('확인 내용: '+$result.failure) }
    if($result.Contains('archiveFailure')) { Write-Host ('압축 오류: '+$result.archiveFailure) }
    if($result.Contains('launchSkipped')) { Write-Host $result.launchSkipped }
    Write-Host '진단 결과는 자동으로 전송되지 않습니다. 실행 중인 앱은 그대로 둡니다.'
}
if(-not $result.diagnosticCompleted) { exit 1 }
